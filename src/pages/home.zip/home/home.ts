import { Component, ViewChild } from '@angular/core';
import { NavController, ModalController, LoadingController, Content } from 'ionic-angular';
import { FormControl } from '@angular/forms';
import { ListPage } from '../list/list';
import { ProfilePage } from '../profile/profile';
import { TraitService } from '../../services/traits.service';
import { SearchBarPage } from '../search-bar/search-bar';


declare var $: any;


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  @ViewChild("contentRef") contentHandle: Content;
  @ViewChild('searchInput') myInput;
  searchControl: FormControl;

  showSearchBar: Boolean = false;
  search_string; 
 
  public searchbar;
  public loading;
  filled: boolean = true;
  popularTraits = [];
  checkedTraits = [];
  checkedTraits_master:any = [];
  scrollHt: number = 0;
  topOrBottom;
  contentBox;
  tabBarHeight;

  traitsMasterList;
  master_list;


  constructor(public navCtrl: NavController, public modalCtrl: ModalController, private traitService: TraitService, private loadingCtrl: LoadingController) {
    this.presentLoadingDefault();
    this.getPopularTraits();
    this.searchControl = new FormControl();
  }

  ionviewDidLoad() { 
    this.searchControl.valueChanges.debounceTime(300).subscribe(search => {
      this.filterTraits();
    });
  }

  presentLoadingDefault() {
    this.loading = this.loadingCtrl.create({ spinner: 'bubbles' });
  }

  getPopularTraits() {
    this.loading.present();
    this.traitService.getListOfPopularTraits().subscribe(data => {
      this.popularTraits = data;
      this.loading.dismiss();
    })
  }

  getMasterTraitList() {
    var loader = this.loadingCtrl.create({ spinner: 'bubbles' });
    loader.present();
	let x = localStorage.getItem('activeTraits');
	let allTraitsData = JSON.parse(x);
	if(allTraitsData.length > 5){
		this.master_list = allTraitsData;
		this.traitsMasterList = allTraitsData;
		loader.dismiss();
	}else{
		this.traitService.getAllTrais().subscribe(data => {
		this.master_list = data;
		this.traitsMasterList = this.master_list; 
		loader.dismiss();
    });
  }
  }
	masterListAddSelectClass(){
		let TIME_IN_MS = 10;
		let hideFooterTimeout = setTimeout( () => {
		$('.masterListStyle').removeClass('checkedMasterStyle');
		$('.singleTraits').removeClass('checkedStyle'); 
		
 		for (var i = 0; i < this.checkedTraits_master.length; i++) {
			$('.singleTraits.' +    this.checkedTraits_master[i].traituniqueid).addClass('checkedStyle');
			$('.masterListStyle.' + this.checkedTraits_master[i].traituniqueid).addClass('checkedMasterStyle');
			//$('.singleTraits.' +    this.checkedTraits_master[i].traituniqueid+" input[type='checkbox']").prop('checked');
			//$('.masterListStyle.' + this.checkedTraits_master[i].traituniqueid+" input[type='checkbox']").prop('checked');
			
		}
		
		for (var i = 0; i < this.checkedTraits.length; i++) {
			$('.singleTraits.' +    this.checkedTraits[i].traituniqueid).addClass('checkedStyle');
			$('.masterListStyle.' + this.checkedTraits[i].traituniqueid).addClass('checkedMasterStyle');
			//$('.singleTraits.' +    this.checkedTraits[i].traituniqueid+" input[type='checkbox']").prop('checked');
			//$('.masterListStyle.' + this.checkedTraits[i].traituniqueid+" input[type='checkbox']").prop('checked');
		}
		}, TIME_IN_MS);
	}

  filterTraits() {
    let str = this.search_string;
    if (str && str.trim() != '') { 
      this.traitsMasterList = this.master_list.filter((item) => {
        return ((item.traitname.toLowerCase().indexOf(str.toLowerCase()) > -1));
      });
	let customTrait = {traitname: str, traitdescription: null, traiticonpath: null, traituniqueid: str+"_NewCustom"}
		//{traitgivenfor:"0",traitname:"Absentminded",traituniqueid:"00000"}

	this.traitsMasterList.push(customTrait);
	this.masterListAddSelectClass();
    }
  }

  toggleMenu() {
    let addModal = this.modalCtrl.create('MenuPage');
    addModal.onDidDismiss(() => {
      return false;
    });
    addModal.present();
  }

  openProfilePage() {
    this.navCtrl.setRoot(ProfilePage);
  }

  openTraitsList() {
    this.navCtrl.push('TraitsListPage');
  }

  openWalkthrough() {
    let addModal2 = this.modalCtrl.create('SlidesPage');
    addModal2.onDidDismiss(() => {
      return false;
    });
    addModal2.present();
  }

  updateCheckedOptions(traitObj, event) {

    let traitData = {
      traitname: traitObj.traitname,
      traituniqueid: traitObj.traituniqueid,
      traitgivenfor: "0"
    }

    if (event.target.checked == true) {
      this.checkedTraits.push(traitData);
    } else {
      for (var i = 0; i < this.checkedTraits.length; i++)
        if (this.checkedTraits[i].traituniqueid == traitObj.traituniqueid) {
          this.checkedTraits.splice(i, 1);
          break;
        }
    }
    console.log(this.checkedTraits);
	this.masterListAddSelectClass();
  }

  checkedOptionsFromMasterList(traitObj, event) {
    let trait_data = {
      traitname: traitObj.traitname,
      traituniqueid: traitObj.traituniqueid,
      traitgivenfor: "0"
    }

    if (event.target.checked == true) {
      this.checkedTraits_master.push(trait_data);
    } else {
      for (var i = 0; i < this.checkedTraits_master.length; i++)
        if (this.checkedTraits_master[i].traituniqueid == traitObj.traituniqueid) {
          this.checkedTraits_master.splice(i, 1);
          break;
        }
    }
    console.log(this.checkedTraits_master);  
    this.masterListAddSelectClass();
 
  }

  searchDone(){
    this.showSearchBar = false;
    
	//Array.prototype.push.apply(this.checkedTraits,this.checkedTraits_master); 
	let tempArr = [];
	this.checkedTraits.forEach(item => {
		if(tempArr.indexOf(item.traituniqueid) == -1){
			tempArr.push(item.traituniqueid);
		}
		this.checkedTraits_master.forEach(itemMast => {
			if(tempArr.indexOf(itemMast.traituniqueid) == -1){
				tempArr.push(itemMast.traituniqueid);
				this.checkedTraits.push(itemMast);
			}
		});
		
	});
	
	
	console.log('=================================');
	console.log(this.checkedTraits);	
	this.masterListAddSelectClass();
	this.search_string = null;
  }
  
  search() {
    this.getMasterTraitList();
    this.showSearchBar = true;
	this.masterListAddSelectClass();
  }

  cancelSearch() {
    this.showSearchBar = false;	
	this.masterListAddSelectClass();
	this.search_string = null;
  }

  addToPage() {
    this.traitService.addTraitToPage(this.checkedTraits).subscribe(data => {
      //alert(JSON.stringify(data));
      if (data.status != "error") {
        this.openProfilePage();
      }
    })
  }


  ionViewDidEnter() {
    this.topOrBottom = this.contentHandle._tabsPlacement;
    this.contentBox = document.querySelector(".scroll-content")['style'];

    if (this.topOrBottom == "top") {
      this.tabBarHeight = this.contentBox.marginTop;
    } else if (this.topOrBottom == "bottom") {
      this.tabBarHeight = this.contentBox.marginBottom;
    }
  }

  scrollingFun(e) {
    if (e.scrollTop > this.scrollHt) {
      $(".tabbar").css("display", "none");
      if (this.topOrBottom == "top") {
        this.contentBox.marginTop = 0;
      } else if (this.topOrBottom == "bottom") {
        this.contentBox.marginBottom = 0;
      }
    } else {
      $(".tabbar").css("display", "flex");
      // document.querySelector(".tabbar")['style'].display = 'flex';
      if (this.topOrBottom == "top") {
        this.contentBox.marginTop = this.tabBarHeight;
      } else if (this.topOrBottom == "bottom") {
        this.contentBox.marginBottom = this.tabBarHeight;
      }
    }
    this.scrollHt = e.scrollTop;
  }


}
