import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { BadgesListPage } from '../badges-list/badges-list';

/**
 * Generated class for the BadgesAvailablePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-badges-available',
  templateUrl: 'badges-available.html',
})
export class BadgesAvailablePage {
	public pageFor = 'availableBadges';
	constructor(public navCtrl: NavController, public navParams: NavParams) {
		this.pageFor = navParams.get('pageFor');	//availableBadges  --or--  givenBadges
	}

	ionViewDidLoad() {
	console.log('ionViewDidLoad BadgesAvailablePage');
	}

	openBadgesMasterList(){
		this.navCtrl.push('BadgesListPage');
	}

}
