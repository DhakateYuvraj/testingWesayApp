import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BadgesAvailablePage } from './badges-available';

@NgModule({
  declarations: [
    BadgesAvailablePage,
  ],
  imports: [
    IonicPageModule.forChild(BadgesAvailablePage),
  ],
})
export class BadgesAvailablePageModule {}
