import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResendOtpPage } from './resend-otp';

@NgModule({
  declarations: [
    ResendOtpPage,
  ],
  imports: [
    IonicPageModule.forChild(ResendOtpPage),
  ],
})
export class ResendOtpPageModule {}
